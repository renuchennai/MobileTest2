package Assignment;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class LoginIntoDemoWebShop {

		@SuppressWarnings("resource")
		public static void main(String[] args) throws IOException, InterruptedException {
		DesiredCapabilities capability= new DesiredCapabilities();
		capability.setCapability(MobileCapabilityType.DEVICE_NAME, "Renuga");
		capability.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		capability.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
		@SuppressWarnings("rawtypes")
		AndroidDriver driver=new AndroidDriver(new URL("http://0.0.0.0:4723/wd/hub"),capability);
		driver.get("http://demowebshop.tricentis.com/login");
		
		FileInputStream file=new FileInputStream("C://Users//RenugadeviSomasundar//eclipse-workspace//Mobile Testing2//Userdetails.xls");
			
		HSSFWorkbook w=new HSSFWorkbook(file);
		HSSFSheet Sheet = w.getSheet("input");
		
		HSSFRow r1=Sheet.getRow(0);
		System.out.println(r1);
		HSSFCell c1=r1.getCell(0); 
		System.out.println(c1);
		HSSFCell c2=r1.getCell(1);
		System.out.println(file);
		String username = c1.getStringCellValue();
		String password = c2.getStringCellValue();
		driver.findElement(By.xpath("//input[@id='Email']")).sendKeys(username);
		System.out.println(password);
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys(password);
		driver.hideKeyboard();
		driver.findElement(By.xpath("//input[@value='Log in']")).click();
//		driver.get("http://demowebshop.tricentis.com/"); 
		Thread.sleep(15000);
		driver.findElement(By.xpath("//div[@id='mob-menu-button']/a/span[2]")).click();
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/ul[2]/li[3]/a")).click();
		Thread.sleep(12000);
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[1]/div[1]/div/div/a/img")).click();
		Thread.sleep(12000);
		driver.findElement(By.xpath("//a[@href='/camera-photo']")).click();
		Thread.sleep(12000);
		driver.findElement(By.name("products-viewmode")).click();
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[1]")).click();
  }
}


